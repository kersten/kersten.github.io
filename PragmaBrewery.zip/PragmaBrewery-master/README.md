# PragmaBrewery

## Description

### Situation

Currently Shane is not able to monitor his loaded containers in the PragmaBrewery Truck. Therefore he is not able to be sure his loaded beer has always the temperature that is needed to keep cooling chain.

### Task

Implement a technology stack that enables Shane to monitor his loaded containers.

### Action

* Implemented container sonsor based on docker container ( emulating temperature change every 5 seconds )
* Implemented server that keeps track of loaded and unloaded containers and publishes its interface via REST to the sensors and the WebClient.
* Implemented a WebClient, that receives its information from the server,  to visualize the loaded containers and their temperatures.

### Result

Shane is now able to monitor the temperatures of his containers in a simple way. He only needs to look at his Monitoring display in the truck to see if his beer is in the right temperature range. 

## System Design

### Server

The Server was designed with a minimum of external dependencies. So it only consists of basic node libraries that ship within `nodejs` itself. As a requirement that would not be needed in a real application would be the `dockernode` thingy, because it is only used to start the emulated sensors.

### Client

The client was designed with a single HTML file to keep it simple. It uses jQuery to have at least some basic `.ajax` and DOM manipulating stuff.

For the css [bulma](http://bulma.io/) is used.

### Sensor emulation

To emulate the temperature sensors a dedicated docker image is used. For every loaded container a docker container is booted. The booted container is then updating its temperature every 5 seconds by calling the PragmaBrewery mock temperature endpoint at [https://temperature-sensor-service.herokuapp.com/sensor/{id}](https://temperature-sensor-service.herokuapp.com/sensor/{id}). 

## Requirements

Following requirements need to be met

* [node](https://nodejs.org/de/download/)
* [npm](https://www.npmjs.com/get-npm)
* [docker](https://docs.docker.com/install/)
* [docker-compose](https://docs.docker.com/compose/install/)

Please refer to the websites to find some docs on installing them.

## Installation

To install all dependencies that are coming with `PragmaBrewery` just execute the command inside the root directory of the repository.

```npm install```

## Testing

To test the server and the sensor code just execute the command inside the root directory of the repository.

```npm test```

## Usage

To start the truck temperature monitoring system, execute the command inside the root directory of the repository.

```npm start```

After the docker has launched its containers, visit [http://localhost:8080](http://localhost:8080)

    Hint: There is no need to run install and test on its own, one can install, build, test with only running npm start 

## Known issues

As for now the unloaded container is not stopped inside the docker network. That might end up with a system having running hundreds of docker containers. 

## Version 2.0 and later

### Container Sensor

* I would recommend to switch from the REST API to a PUB/SUB pattern e.g. [mqtt](http://mqtt.org/).
* Another, maybe better, idea would be to implement [prometheus](https://prometheus.io/)

### Server

* A database containing the historical values is inevitable. Shane is currently not in a position to know if his loaded goods were outside the allowed temperature range, as he only ever sees the actual state. Should he leave the door open during unloading and talk to the bar owner for an abnormally long time, it may happen that he closes the door on the way back and the temperatures are already in the normal range again as soon as he looks at the monitoring.

### Truck UI

* Implement e2e test
* I would recommend to implement the UI with [flutter([https://flutter.dev) to be able to use the notification system by Android or ios/iPadOs.
* Instead of a REST-API I would implement WebSockets to remove the interval requests to get the current container temperature.
* Adding a detailed history view per container would be helpful to see if the temperature was outside the ranges in the past. 

## General ideas

### Federated Blockchain

For future versions I would like to ask all bars to setup a blockchain node. Then I would extend the container sensor to transmit its information to the blockchain wia some EDGE/LTE/LoraWAN network.

With this information all participants are sure that the beer was never outside of its given temperature range, provided all parties can trust each other.

As it is all about trust, there are some problems that would need to be solved.

But the idea sounds quite nice, that even the end customer sitting in the bar could drinking his beer, could check e.g on which farm his wheat inside the beer came from.
