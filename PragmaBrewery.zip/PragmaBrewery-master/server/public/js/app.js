$( document ).ready( () => {
    console.log( "Truck ui ready" );

    const tempratureState = {
        0: { text: "Unknown temperature", class: "warning" },
        1: { text: "Temperature OK", class: "success" },
        2: { text: "WARNING: Temperature to high", class: "danger" },
        3: { text: "WARNING: Temperature to low", class: "danger" }
    };

    $( "#load-truck" ).click( () => {
        $( ".modal" ).addClass( "is-active" );

        $( ".load-container" ).click( ( event ) => {
            $( event.target ).addClass( "is-loading" );

            $.ajax( {
                type:        "POST",
                url:         "/api/v1/container",
                dataType:    "json",
                contentType: "application/json",
                data:        JSON.stringify( {
                    name:               $( event.target ).data( "name" ),
                    refrigerationNeeds: {
                        min: $( event.target ).data( "temperature-range-min" ),
                        max: $( event.target ).data( "temperature-range-max" )
                    }
                } ),
                success:     () => {
                    $( event.target ).removeClass( "is-loading" );
                }
            } );
        } );

        $( ".close" ).one( "click", () => {
            $( ".modal" ).removeClass( "is-active" );
            $( ".close, .load-container" ).unbind( "click" );
        } );
    } );

    setInterval( () => {
        $.get( "/api/v1/container", ( data ) => {
            data.forEach( ( container ) => {
                let $cEl = $( `#${ container.id }` );

                if ( $cEl.length === 0 ) {
                    $cEl = $( "#container-template" ).clone();

                    $cEl.attr( "id", container.id );

                    $( ".name", $cEl ).text( container.name );
                    $( ".range", $cEl ).text( `${ container.refrigerationNeeds.min } - ${ container.refrigerationNeeds.max }` );

                    $cEl.css( "display", "block" );

                    $( ".unload-container", $cEl ).one( "click", () => {
                        $.ajax( {
                            url:     `/api/v1/container/${ container.id }`,
                            method:  "DELETE",
                            success: () => {
                                console.log( "DELETED" );

                                $( `#${ container.id }` ).remove();
                            }
                        } )
                    } );

                    $( "#containers" ).append( $cEl );
                }

                if ( container.temperatureState !== 0 ) {
                    $( ".current-temperature", $cEl ).text( `${ container.temperature }°C` );
                }

                if ( !$( ".temperature-tag", $cEl ).hasClass( `is-${ tempratureState[ container.temperatureState ].class }` ) ) {
                    $( ".temperature-tag", $cEl ).attr( "class", ( i, c ) => {
                        return c.replace( /(^|\s)is-\S+/g, "" );
                    } );

                    $( ".temperature-tag", $cEl ).addClass( `is-${ tempratureState[ container.temperatureState ].class }` );
                }

                $( ".temperature-tag", $cEl ).text( tempratureState[ container.temperatureState ].text );
            } );
        } );
    }, 1000 );
} );
