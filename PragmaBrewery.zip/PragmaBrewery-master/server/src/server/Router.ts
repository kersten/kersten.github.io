import { readFileSync } from "fs";
import { lookup } from "mime-types";
import { join } from "path";
import { parse } from "url";
import { HttpMethod } from "../types";
import { Handler, MethodCallback } from "./Handler";
import { Request } from "./Request";

export class Router {
    private _handlers: { [ method: string ]: { [ url: string ]: Handler } } = {
        [ HttpMethod.GET ]:    {},
        [ HttpMethod.POST ]:   {},
        [ HttpMethod.PUT ]:    {},
        [ HttpMethod.DELETE ]: {}
    };

    public register ( method: string, url: string, callback: MethodCallback ) {
        this._handlers[ method.toUpperCase() ][ url ] = new Handler( callback );
    }

    public route ( req: Request ): Handler {
        const url = parse( req.url || "", true );

        if ( req.method === undefined ) {
            req.method = "GET";
        }

        let handler = this.match( req.method, url.pathname!, req );

        if ( !handler ) {
            handler = this.missing( req );
        }

        return handler;
    }

    private match ( method: string, pathname: string, req: Request ): Handler | undefined {
        if ( this._handlers[ method ][ pathname ] ) {
            return this._handlers[ method ][ pathname ];
        }

        let handler: Handler | undefined = undefined;

        Object.keys( this._handlers[ method ] ).forEach( ( path ) => {
            if ( handler ) {
                return;
            }

            const originalPath = path;
            const parts = path.match( /(:.*?(\/|$))/gmi );

            if ( parts ) {
                path = path.replace( new RegExp( /\//, "gi" ), "\\/" );

                parts.forEach( part => {
                    const regEx = part.replace( new RegExp( /[\/]+$/ ), "" );
                    path = path.replace( regEx, `(?<${ regEx.replace( new RegExp( /^[:]+/ ), "" ) }>.*?)` );
                } );

                path = path + "$";
                const match = new RegExp( `${ path }`, "ig" ).exec( pathname );

                if ( match !== null ) {
                    handler = this._handlers[ method ][ originalPath ];
                    req.params = { ...match.groups };
                }
            }
        } );

        return handler;
    }

    private missing ( req: Request ) {
        /**
         * Parse URL with parsed query string parameters
         * @type {UrlWithParsedQuery}
         */
        const url = parse( req.url || "", true );

        if ( url.pathname === "/" ) {
            url.pathname = "/index.html";
        }

        /**
         * build local path to requested file and replace all occurrences of "../" to only allow absolute paths
         * @type {string}
         */
        const path = join( __dirname, "..", "..", "public", url.pathname!.replace( /\.\.\//, "" ) );

        /**
         * try to load file, otherwise return a 404
         */
        try {
            const data = readFileSync( path );
            const mime = lookup( path ) || "application/octet-stream";

            return new Handler( ( req, res ) => {
                res.writeHead( 200, { "Content-Type": mime } );
                res.write( data );
                res.end();
            } );
        } catch ( e ) {
            return new Handler( ( req, res ) => {
                res.writeHead( 404, { "Content-Type": "text/plain" } );
                res.write( "No route registered for " + url.pathname );
                res.end();
            } );
        }
    }
}
