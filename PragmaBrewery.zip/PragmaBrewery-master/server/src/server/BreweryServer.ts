import { Server } from "http";
import { MethodCallback } from "./Handler";
import { Request } from "./Request";
import { Router } from "./Router";

export class BreweryServer extends Server {
    private readonly _router: Router = new Router();

    constructor () {
        super( {
            IncomingMessage: Request
        }, ( req, res ) => {
            const request: Request = <Request> req;
            const handler = this.router.route( request );

            if ( request.method === "POST" || request.method === "PUT" ) {
                let body: Buffer[] = [];

                request.on( "data", ( chunk ) => {
                    body.push( chunk );
                } ).on( "end", () => {
                    const bodyStr = Buffer.concat( body ).toString();

                    if ( request.headers && request.headers[ "content-type" ] === "application/json" && bodyStr ) {
                        request.body = JSON.parse( bodyStr );
                    }

                    handler.process( request, res );
                } );
            } else {
                handler.process( request, res );
            }
        } );
    }

    get router (): Router {
        return this._router;
    }

    public get ( url: string, method: MethodCallback ): void {
        this._router.register( "GET", url, method );
    }

    public post ( url: string, method: MethodCallback ): void {
        this._router.register( "POST", url, method );
    }

    public put ( url: string, method: MethodCallback ): void {
        this._router.register( "PUT", url, method );
    }

    public delete ( url: string, method: MethodCallback ): void {
        this._router.register( "DELETE", url, method );
    }
}
