import { IncomingMessage } from "http";
import { Socket } from "net";

export class Request extends IncomingMessage {
    private _params: any;
    private _body: any;

    constructor ( socket: Socket ) {
        super( socket );
    }

    get params() {
        return this._params;
    }

    set params( params ) {
        this._params = params;
    }

    get body() {
        return this._body;
    }

    set body( body ) {
        this._body = body;
    }
}
