import { ServerResponse } from "http";
import { Request } from "./Request";

export type MethodCallback = ( req: Request, res: ServerResponse ) => any;

export class Handler {
    private readonly _method: Function;

    constructor ( method: MethodCallback ) {
        this._method = method;
    }

    public process ( req: Request, res: ServerResponse ) {
        return this._method.apply( this, [ req, res ] );
    }
}
