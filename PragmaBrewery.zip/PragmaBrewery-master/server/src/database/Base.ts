import { ContainerModel } from "../models/ContainerModel";

export abstract class Base {
    protected readonly _models: Map<string, ContainerModel>;

    constructor () {
        this._models = new Map<string, any>();
    }

    public find ( id: string ): ContainerModel | undefined {
        return this._models.get( id );
    }

    public findAll (): Array<ContainerModel> {
        const toReturn: Array<ContainerModel> = [];

        this._models.forEach( value => toReturn.push( value ) );

        return toReturn;
    }

    public remove ( id: string ): boolean {
        return this._models.delete( id );
    }

    public removeAll (): Map<string, ContainerModel> {
        this._models.clear();
        return this._models;
    }
}
