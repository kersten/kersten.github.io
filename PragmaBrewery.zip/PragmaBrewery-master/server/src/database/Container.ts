import uuid from "uuid/v4";
import { ContainerModel } from "../models/ContainerModel";
import { Base } from "./Base";

export class Container extends Base {
    private static instance: Container;

    static getInstance(): Container {
        if (!Container.instance) {
            Container.instance = new Container();
        }

        return Container.instance;
    }

    private generateId (): string {
        return uuid();
    }

    public persist ( model: ContainerModel ): ContainerModel {
        let id = this.generateId();

        while ( this.find( id ) ) {
            id = this.generateId();
        }

        model.id = id;

        this._models.set( id, model );

        return model;
    }
}
