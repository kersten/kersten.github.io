export abstract class AbstractModel {
    public toJSON (): string {
        return this._onlyGetters( this );
    }

    private _onlyGetters ( obj: any ): any {
        // Gotchas: types for which typeof returns "object"
        if ( obj === null || obj instanceof Array || obj instanceof Date ) {
            return obj;
        }

        let onlyGetters: any = {};

        // Iterate over each property for this object and its prototypes. We'll get each
        // property only once regardless of how many times it exists on parent prototypes.
        for ( let key in obj ) {
            let proto = obj;

            if ( key.substring( 0, 1 ) === "_" ) {
                key = key.substring( 1 );
            }

            // Check getOwnPropertyDescriptor to see if the property is a getter. It will only
            // return the descriptor for properties on this object (not prototypes), so we have
            // to walk the prototype chain.
            while ( proto ) {
                let descriptor = Object.getOwnPropertyDescriptor( proto, key );

                if ( descriptor && descriptor.get ) {
                    // Access the getter on the original object (not proto), because while the getter
                    // may be defined on proto, we want the property it gets to be the one from the
                    // lowest level
                    let val = obj[ key ];

                    onlyGetters[ key ] = val;

                    proto = null;
                } else {
                    proto = Object.getPrototypeOf( proto );
                }
            }
        }

        return onlyGetters;
    }
}
