import { ContainerTemperatureState } from "../constants";
import { Container } from "../database/Container";
import { IContainer } from "../interfaces/IContainer";
import { IBeerRefrigerationNeeds } from "../interfaces/IBeerRefrigerationNeeds";
import { AbstractModel } from "./AbstractModel";

export class ContainerModel extends AbstractModel implements IContainer {
    private readonly _db: Container = Container.getInstance();

    private _id?: string;
    private _created?: Date;
    private _name: string;
    private readonly _refrigerationNeeds: IBeerRefrigerationNeeds;

    private _temperature: number | null = null;
    private _temperatureState: ContainerTemperatureState = ContainerTemperatureState.UNKNOWN;

    constructor ( name: string, refrigerationNeeds: IBeerRefrigerationNeeds ) {
        super();

        this._name = name;
        this._refrigerationNeeds = refrigerationNeeds;
    }

    public set id ( id: string | undefined ) {
        this._id = id;
    }

    public get id (): string | undefined {
        return this._id;
    }

    public get created (): Date | undefined {
        return this._created;
    }

    public get name (): string {
        return this._name;
    }

    public set name ( name: string ) {
        this._name = name;
    }

    public get refrigerationNeeds (): IBeerRefrigerationNeeds {
        return this._refrigerationNeeds;
    }

    public get temperature (): number | null {
        return this._temperature;
    }

    public set temperature ( value: number | null ) {

        if ( value === null ) {
            this._temperatureState = ContainerTemperatureState.UNKNOWN;
            this._temperature = value;
            return;
        }

        if ( value < this.refrigerationNeeds.min ) {
            this._temperatureState = ContainerTemperatureState.LOW;
        } else if ( value > this.refrigerationNeeds.max ) {
            this._temperatureState = ContainerTemperatureState.HIGH;
        } else {
            this._temperatureState = ContainerTemperatureState.NORMAL;
        }

        this._temperature = value;
    }

    public get temperatureState (): ContainerTemperatureState {
        return this._temperatureState;
    }

    public persist(): ContainerModel {
        this.id = this._db.persist( this ).id;
        this._created = new Date();

        return this;
    }
}
