import { ContainerTemperatureState } from "../constants";
import { IBeerRefrigerationNeeds } from "./IBeerRefrigerationNeeds";

export interface IContainer {
    id?: string;
    name: string;
    refrigerationNeeds: IBeerRefrigerationNeeds;
    temperature: number | null;
    temperatureState: ContainerTemperatureState;
}
