export interface IBeerRefrigerationNeeds {
    min: number;
    max: number;
}
