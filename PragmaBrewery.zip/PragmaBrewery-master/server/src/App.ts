import Dockerode from "dockerode";
import { Container } from "./database/Container";
import { ContainerModel } from "./models/ContainerModel";
import { BreweryServer } from "./server/BreweryServer";

export class App {
    private readonly _server: BreweryServer;
    private readonly _containerDb: Container = Container.getInstance();
    private readonly _docker = new Dockerode( { socketPath: "/var/run/docker.sock" } );

    constructor () {
        this._server = new BreweryServer();

        this.registerRoutes();
    }

    get server (): BreweryServer {
        return this._server;
    }

    private registerRoutes (): void {
        this._server.get( "/api/v1/container", ( req, res ) => {
            res.writeHead( 200, { "Content-Type": "application/json" } );
            res.write( JSON.stringify( this._containerDb.findAll() ) );
            res.end();
        } );

        // Get all registered containers
        this._server.post( "/api/v1/container", ( req, res ) => {
            if ( !req.body || !req.body.name || !req.body.refrigerationNeeds ) {
                res.writeHead( 412, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Wrong parameters set" } ) );
                res.end();
                return;
            }

            res.writeHead( 200, { "Content-Type": "application/json" } );

            const beer = new ContainerModel( req.body.name,
                { min: req.body.refrigerationNeeds.min, max: req.body.refrigerationNeeds.max } );
            beer.persist();

            // For unit testing purpose: launch a docker container only if inside docker
            if ( process.env.ENVIRONMENT && process.env.ENVIRONMENT === "production" ) {
                this._docker.createContainer( {
                    Image:            "container:latest",
                    NetworkingConfig: {
                        EndpointsConfig: {
                            pragambrewery: { NetworkID: "pragambrewery" }
                        }
                    },
                    HostConfig:       {
                        Links: [ process.env.HOSTNAME ]
                    },
                    Env:              [
                        `ID=${ beer.id }`,
                        `SERVER=${ process.env.HOSTNAME }`,
                    ]
                }, ( error, container ) => {
                    if ( error || !container ) {
                        throw Error( error );
                    }

                    container.start( ( err, data ) => {
                        if ( err ) {
                            throw Error( err );
                        }

                        res.write( JSON.stringify( beer ) );
                        res.end();
                    } );
                } );
            } else {
                res.write( JSON.stringify( beer ) );
                res.end();
            }
        } );

        // Get container with id
        this._server.get( "/api/v1/container/:id", ( req, res ) => {
            res.writeHead( 200, { "Content-Type": "application/json" } );

            const container = this._containerDb.find( req.params.id );

            if ( container ) {
                res.writeHead( 200, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( container ) );
            } else {
                res.writeHead( 404, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Container not found" } ) );
            }

            res.end();
        } );

        // Handle container update
        this._server.put( "/api/v1/container/:id", ( req, res ) => {
            if ( !req.body ) {
                res.writeHead( 412, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Missing container parameters to update" } ) );
                res.end();
                return;
            }

            if ( req.body.id ) {
                res.writeHead( 412, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Container id cannot be updated" } ) );
                res.end();
                return;
            }

            const container = this._containerDb.find( req.params.id );

            if ( container ) {
                res.writeHead( 200, { "Content-Type": "application/json" } );
                container.name = req.body.name;
                res.write( JSON.stringify( container ) );
            } else {
                res.writeHead( 404, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Container not found" } ) );
            }


            res.end();
        } );

        this._server.delete( "/api/v1/container/:id", ( req, res ) => {
            const container = this._containerDb.find( req.params.id );

            if ( container ) {
                res.writeHead( 200, { "Content-Type": "application/json" } );
                this._containerDb.remove( req.params.id );
                res.write( JSON.stringify( { success: true, message: "Container deleted" } ) );
            } else {
                res.writeHead( 404, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Container not found" } ) );
            }

            res.end();
        } );

        this._server.delete( "/api/v1/container", ( req, res ) => {
            res.writeHead( 403, { "Content-Type": "application/json" } );
            res.write( JSON.stringify( { success: false, message: "Delete all conatiners is not allowed" } ) );


            res.end();
        } );

        // Get container temperature
        this._server.get( "/api/v1/container/:id/temperature", ( req, res ) => {
            res.writeHead( 200, { "Content-Type": "application/json" } );
            res.write( JSON.stringify( this._containerDb.find( req.params.id ) ) );
            res.end();
        } );

        // Update container temperature
        this._server.post( "/api/v1/container/:id/temperature", ( req, res ) => {
            res.writeHead( 200, { "Content-Type": "application/json" } );

            if ( !req.body || !req.body.temperature ) {
                res.writeHead( 412, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Wrong parameters set" } ) );
                res.end();
                return;
            }

            const container = this._containerDb.find( req.params.id );

            if ( container ) {
                container.temperature = req.body.temperature;
                res.write( JSON.stringify( container ) );
            } else {
                res.writeHead( 404, { "Content-Type": "application/json" } );
                res.write( JSON.stringify( { success: false, message: "Container not found" } ) );
            }

            res.end();
        } );
    }

    start (): BreweryServer {
        return this._server.listen( process.env.PORT || 8080 );
    }
}

console.log( `Server started on port ${ process.env.PORT || 8080 }` );
