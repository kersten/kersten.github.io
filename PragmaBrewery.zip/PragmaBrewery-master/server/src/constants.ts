export enum ContainerTemperatureState {
    UNKNOWN,
    NORMAL,
    HIGH,
    LOW
}

export enum APIResult {
    SUCCESS = "success",
    FAILURE = "failure",
}
