import { expect } from "chai";
import { ContainerTemperatureState } from "../../src/constants";
import { Container } from "../../src/database/Container";
import { ContainerModel } from "../../src/models/ContainerModel";

describe( "Database Container Table", () => {
    const db = Container.getInstance();
    let lastId: string;

    it( "should return 0 containers", () => {
        expect( db.findAll() ).to.be.an( "array" );
        expect( db.findAll().length ).to.be.equal( 0 );
    } );

    it( "should return 10 new containers", () => {
        for ( let i = 1; i <= 10; i++ ) {
            const container = new ContainerModel( `Pilsner ${ i }`, { min: 4, max: 6 } );
            container.persist();

            if ( container.id !== undefined ) {
                lastId = container.id;
            }
        }

        expect( db.findAll() ).to.be.an( "array" );
        expect( db.findAll().length ).to.be.equal( 10 );
    } );

    it( "should return undefined for unknown container", () => {
        expect( db.find( "1" ) ).to.be.undefined;
    } );

    it( "should return 1 container", () => {
        const container = db.find( lastId );

        if ( container ) {
            expect( container ).to.be.a( "object" );
            expect( container.name ).to.be.equal( "Pilsner 10" );
            expect( container.refrigerationNeeds.min ).to.equal( 4 );
            expect( container.refrigerationNeeds.max ).to.equal( 6 );
            expect( container.temperature ).to.be.null;
            expect( container.temperatureState ).to.be.equal( ContainerTemperatureState.UNKNOWN );
        } else {
            throw "Container not found";
        }
    } );

    it( "should delete 1 container", () => {
        db.remove( lastId );

        const container = db.find( lastId );

        expect( container ).to.be.undefined;
    } );

    it( "should delete all containers", () => {
        db.removeAll();

        expect( db.findAll() ).to.be.an( "array" );
        expect( db.findAll().length ).to.be.equal( 0 );
    } );
} );
