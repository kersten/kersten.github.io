import { expect } from "chai";
import { ContainerTemperatureState } from "../../src/constants";
import { ContainerModel } from "../../src/models/ContainerModel";

describe( "Pilsner ContainerModel", () => {
    let container: ContainerModel;

    beforeEach( () => {
        container = new ContainerModel( "Pilsner", { min: 4, max: 6 } );
    } );

    it( "should return new Pilsner ContainerModel", () => {
        expect( container.id ).to.be.undefined;
        expect( container.created ).to.be.undefined;
        expect( container.name ).to.be.equal( "Pilsner" );
        expect( container.refrigerationNeeds.min ).to.equal( 4 );
        expect( container.refrigerationNeeds.max ).to.equal( 6 );
        expect( container.temperature ).to.be.null;
        expect( container.temperatureState ).to.be.equal( ContainerTemperatureState.UNKNOWN );
    } );

    it( "should return all keys on JSON.stringify", () => {
        expect( JSON.parse( JSON.stringify( container ) ) ).to.deep.equal( {
            "name": "Pilsner",
            "refrigerationNeeds": { min: 4, max: 6 },
            "temperature": null,
            "temperatureState": ContainerTemperatureState.UNKNOWN
        } );
    } );

    it( "should return all keys on JSON.stringify on persisted model", () => {
        const newContainer = new ContainerModel( "Pilsner", { min: 4, max: 6 } );
        newContainer.persist();

        expect( JSON.parse( JSON.stringify( newContainer ) ) ).to.deep.equal( {
            "id": newContainer.id,
            "created": JSON.parse( JSON.stringify( newContainer.created ) ),
            "name": "Pilsner",
            "refrigerationNeeds": { min: 4, max: 6 },
            "temperature": null,
            "temperatureState": ContainerTemperatureState.UNKNOWN
        } );
    } );

    it( "should return null on current temperature", () => {
        expect( container.temperature ).to.be.equal( null );
    } );

    it( "should return current temperature", () => {
        container.temperature = 5;
        expect( container.temperature ).to.be.equal( 5 );
    } );

    it( "should update current temperature from 5 to 6", () => {
        container.temperature = 5;
        expect( container.temperature ).to.be.equal( 5 );

        container.temperature = 6;
        expect( container.temperature ).to.be.equal( 6 );
    } );

    it( "should change to LOW if temperature is below 4", () => {
        container.temperature = 3;
        expect( container.temperatureState ).to.be.equal( ContainerTemperatureState.LOW );
    } );

    it( "should change to HIGH if temperature is above 6",() => {
        container.temperature = 7;
        expect( container.temperatureState ).to.be.equal( ContainerTemperatureState.HIGH );
    } );

    it( "should change to NORMAL if temperature is between 4 and 6",() => {
        container.temperature = 5;
        expect( container.temperatureState ).to.be.equal( ContainerTemperatureState.NORMAL );
    } );
} );
