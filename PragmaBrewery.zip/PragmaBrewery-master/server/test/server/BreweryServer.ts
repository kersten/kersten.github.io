import { expect } from "chai";
import chaiHttp from "chai-http";
import { App } from "../../src/App";
import { ContainerTemperatureState } from "../../src/constants";
import { Container } from "../../src/database/Container";
import chai = require("chai");

chai.use( chaiHttp );

describe( "App", () => {
    const db = Container.getInstance();
    let app: App;

    before( () => {
        app = new App();
    } );

    beforeEach( () => {
        db.removeAll();
    } );

    it( "should return status code 200 on route /", ( done ) => {
        chai.request( app.server ).get( "/" ).end( ( req, res ) => {
            expect( res.status ).to.be.equal( 200 );
            expect( res.type ).to.be.equal( "text/html" );
            done();
        } );
    } );

    it( "should return an empty list of temperature containers on GET /api/v1/container", ( done ) => {
        chai.request( app.server ).get( "/api/v1/container" ).end( ( req, res ) => {
            expect( res.type ).to.be.equal( "application/json" );
            expect( res.body ).to.be.empty;

            done();
        } );
    } );

    it( "should return a 404 with not existing container on GET /api/v1/container/:id", ( done ) => {
        chai.request( app.server ).get( "/api/v1/container/not-existing" ).end( ( req, res ) => {
            expect( res.status ).to.be.equal( 404 );
            expect( res.type ).to.be.equal( "application/json" );

            expect( res.body ).to.be.a( "object" ).to.have.property( "success" );
            expect( res.body ).to.be.a( "object" ).to.have.property( "message" );

            done();
        } );
    } );

    it( "should return a new temperature container on POST /api/v1/container", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( req, res ) => {
            expect( res.type ).to.be.equal( "application/json" );

            expect( res.body ).to.be.a( "object" ).to.have.property( "id" );
            expect( res.body ).to.be.a( "object" ).to.have.property( "created" );

            expect( res.body ).to.deep.equal( {
                id:                 res.body.id,
                created:            res.body.created,
                name:               "Pilsner",
                temperature:        null,
                refrigerationNeeds: {
                    min: 4,
                    max: 6
                },
                temperatureState:   ContainerTemperatureState.UNKNOWN
            } );

            done();
        } );
    } );

    it( "should return a 404 error for update on a missing temperature container on PUT /api/v1/container/:id", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( req, res ) => {
            chai.request( app.server ).put( "/api/v1/container/not-existing" ).send( {
                name: "Pilsner 2"
            } ).end( ( reqPut, resPut ) => {
                expect( resPut.status ).to.be.equal( 404 );
                expect( resPut.type ).to.be.equal( "application/json" );

                expect( resPut.body ).to.be.a( "object" ).to.have.property( "success" );
                expect( resPut.body ).to.be.a( "object" ).to.have.property( "message" );

                done();
            } );
        } );
    } );

    it( "should return a 412 error for update a temperature container on PUT /api/v1/container/:id with missing parameters to update",
        ( done ) => {
            chai.request( app.server ).post( "/api/v1/container" ).send( {
                name:               "Pilsner",
                refrigerationNeeds: {
                    min: 4,
                    max: 6
                }
            } ).end( ( req, res ) => {
                chai.request( app.server ).put( `/api/v1/container/${ res.body.id }` ).send().end( ( reqPut, resPut ) => {
                    expect( resPut.status ).to.be.equal( 412 );
                    expect( resPut.type ).to.be.equal( "application/json" );

                    expect( resPut.body ).to.be.a( "object" ).to.have.property( "success" );
                    expect( resPut.body ).to.be.a( "object" ).to.have.property( "message" );

                    done();
                } );
            } );
        } );

    it( "should return a 412 error for update a temperature container on PUT /api/v1/container/:id with id parameter to update",
        ( done ) => {
            chai.request( app.server ).post( "/api/v1/container" ).send( {
                name:               "Pilsner",
                refrigerationNeeds: {
                    min: 4,
                    max: 6
                }
            } ).end( ( req, res ) => {
                chai.request( app.server ).put( `/api/v1/container/${ res.body.id }` ).send( {
                    id:   "new-id",
                    name: "Pilsner 2"
                } ).end( ( reqPut, resPut ) => {
                    chai.request( app.server ).get( `/api/v1/container/${ res.body.id }` ).end( ( reqGet, resGet ) => {
                        expect( resPut.status ).to.be.equal( 412 );
                        expect( resPut.type ).to.be.equal( "application/json" );

                        expect( resPut.body ).to.be.a( "object" ).to.have.property( "success" );
                        expect( resPut.body ).to.be.a( "object" ).to.have.property( "message" );

                        expect( resGet.status ).to.be.equal( 200 );
                        expect( resGet.type ).to.be.equal( "application/json" );

                        expect( resGet.body ).to.deep.equal( {
                            id:                 res.body.id,
                            created:            res.body.created,
                            name:               "Pilsner",
                            temperature:        null,
                            refrigerationNeeds: {
                                min: 4,
                                max: 6
                            },
                            temperatureState:   ContainerTemperatureState.UNKNOWN
                        } );

                        done();
                    } );
                } );
            } );
        } );

    it( "should return a 200 OK for update on a temperature container on PUT /api/v1/container/:id", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( req, res ) => {
            chai.request( app.server ).put( `/api/v1/container/${ res.body.id }` ).send( {
                name: "Pilsner 2"
            } ).end( ( reqPut, resPut ) => {
                chai.request( app.server ).get( `/api/v1/container/${ res.body.id }` ).end( ( reqGet, resGet ) => {
                    expect( resGet.status ).to.be.equal( 200 );
                    expect( resGet.type ).to.be.equal( "application/json" );

                    expect( resGet.body ).to.be.a( "object" ).to.have.property( "id" );
                    expect( resGet.body ).to.be.a( "object" ).to.have.property( "created" );

                    expect( resGet.body ).to.deep.equal( {
                        id:                 res.body.id,
                        created:            res.body.created,
                        name:               "Pilsner 2",
                        temperature:        null,
                        refrigerationNeeds: {
                            min: 4,
                            max: 6
                        },
                        temperatureState:   ContainerTemperatureState.UNKNOWN
                    } );

                    done();
                } );
            } );
        } );
    } );

    it( "should return a updated temperature container on PUT /api/v1/container/:id", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( req, res ) => {
            expect( res.type ).to.be.equal( "application/json" );

            expect( res.body ).to.be.a( "object" ).to.have.property( "id" );
            expect( res.body ).to.be.a( "object" ).to.have.property( "created" );

            expect( res.body ).to.deep.equal( {
                id:                 res.body.id,
                created:            res.body.created,
                name:               "Pilsner",
                temperature:        null,
                refrigerationNeeds: {
                    min: 4,
                    max: 6
                },
                temperatureState:   ContainerTemperatureState.UNKNOWN
            } );

            done();
        } );
    } );

    it( "should return a temperature container on GET /api/v1/container/:id", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( req, res ) => {
            chai.request( app.server ).get( `/api/v1/container/${ res.body.id }` ).end( ( req2, res2 ) => {
                expect( res2.body ).to.deep.equal( {
                    id:                 res.body.id,
                    created:            res.body.created,
                    name:               "Pilsner",
                    temperature:        null,
                    refrigerationNeeds: {
                        min: 4,
                        max: 6
                    },
                    temperatureState:   ContainerTemperatureState.UNKNOWN
                } );

                done();
            } );
        } );
    } );

    it( "should return a list of two temperature container on GET /api/v1/container", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( () => {
            chai.request( app.server ).post( "/api/v1/container" ).send( {
                name:               "Pilsner",
                refrigerationNeeds: {
                    min: 4,
                    max: 6
                }
            } ).end( () => {
                chai.request( app.server ).get( "/api/v1/container" ).end( ( req, res ) => {
                    expect( res.type ).to.be.equal( "application/json" );
                    expect( res.body ).to.be.an( "array" ).of.length( 2 );

                    done();
                } );
            } );
        } );
    } );

    it( "should delete a temperature container on DELETE /api/v1/container/:id", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( req, res ) => {
            chai.request( app.server ).delete( `/api/v1/container/${ res.body.id }` ).end( ( reqDel, resDel ) => {
                expect( resDel.status ).to.be.equal( 200 );
                expect( resDel.type ).to.be.equal( "application/json" );

                expect( resDel.body ).to.be.a( "object" ).to.have.property( "success" );
                expect( resDel.body ).to.be.a( "object" ).to.have.property( "message" );

                chai.request( app.server ).get( `/api/v1/container/${ res.body.id }` ).end( ( reqGet, resGet ) => {
                    expect( resGet.status ).to.be.equal( 404 );
                    done();
                } );
            } );
        } );
    } );

    it( "should return a 403 not allowed to delete all containers on DELETE /api/v1/container", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( req, res ) => {
            chai.request( app.server ).delete( `/api/v1/container` ).end( ( reqDel, resDel ) => {
                expect( resDel.status ).to.be.equal( 403 );
                expect( resDel.type ).to.be.equal( "application/json" );

                expect( resDel.body ).to.be.a( "object" ).to.have.property( "success" );
                expect( resDel.body ).to.be.a( "object" ).to.have.property( "message" );

                done();
            } );
        } );
    } );

    it( "should return a temperature at conatiner on POST /api/v1/container/:id/temperature", ( done ) => {
        chai.request( app.server ).post( "/api/v1/container" ).send( {
            name:               "Pilsner",
            refrigerationNeeds: {
                min: 4,
                max: 6
            }
        } ).end( ( postReq, postRes ) => {
            chai.request( app.server ).post( `/api/v1/container/${ postRes.body.id }/temperature` ).send( {
                temperature: 5
            } ).end( ( req, res ) => {
                expect( res.type ).to.be.equal( "application/json" );

                expect( res.body ).to.be.a( "object" ).to.have.property( "id" );
                expect( res.body ).to.be.a( "object" ).to.have.property( "created" );

                expect( res.body ).to.deep.equal( {
                    id:                 postRes.body.id,
                    created:            postRes.body.created,
                    name:               "Pilsner",
                    temperature:        5,
                    refrigerationNeeds: {
                        min: 4,
                        max: 6
                    },
                    temperatureState:   ContainerTemperatureState.NORMAL
                } );

                done();
            } );
        } );
    } );

    it( "should return a 404 creating a temperature entry on not existing contaienr POST /api/v1/container/:id/temperature", ( done ) => {
        chai.request( app.server ).post( `/api/v1/container/not-existing/temperature` ).send( {
            temperature: 5
        } ).end( ( req, res ) => {
            expect( res.status ).to.be.equal( 404 );
            expect( res.type ).to.be.equal( "application/json" );

            expect( res.body ).to.be.a( "object" ).to.have.property( "success" );
            expect( res.body ).to.be.a( "object" ).to.have.property( "message" );

            done();
        } );
    } );
} );
