import { Container } from "./Container";

const sensor = new Container();

sensor.start();
