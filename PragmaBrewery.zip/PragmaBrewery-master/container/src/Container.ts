import { request } from "http";
import { ContainerService } from "./service/ContainerService";

export class Container {
    private readonly _endpoint: string;
    private readonly _service: ContainerService;

    constructor () {
        if ( !process.env.ID ) {
            throw Error( "No container ID found" );
        }

        if ( !process.env.SERVER ) {
            throw Error( "No server found" );
        }

        this._endpoint = `/api/v1/container/${ process.env.ID }/temperature`;
        this._service = new ContainerService( process.env.ID );
    }

    private loop () {
        this._service.request().then( value => {
            const postBody = JSON.stringify( {
                temperature: value.temperature
            } );

            const req = request( {
                host:    process.env.SERVER,
                port:    process.env.PORT || 80,
                path:    this._endpoint,
                method:  "POST",
                headers: {
                    "Content-Type":   "application/json",
                    "Content-Length": Buffer.byteLength( postBody )
                }
            }, res => {
                if ( res.statusCode === 404 ) {
                    console.error( 404, res.statusMessage, req.path );
                }

                res.on( "error", err => {
                    console.error( "onError", err.message );
                } );

                res.on( "end", () => {
                    console.log( "Temperature updated" );
                } );
            } );

            req.write( postBody );
        } );
    }

    public start (): void {
        this.loop();

        setInterval( () => {
            this.loop();
        }, 5000 );
    }
}
