import { NotFound } from "@curveball/http-errors";
import { get } from "https";
import { HttpMethod, KeyValue } from "../types";

interface TemperatureResponse {
    id: string;
    temperature: number;
}

export class APIService {
    private _url: string = "https://temperature-sensor-service.herokuapp.com";
    private _endpoint: string = "/";

    private _method: HttpMethod = HttpMethod.GET;
    private _headers: string[][] = [];

    public setHeaders ( headers: KeyValue<string, string>[] ): APIService {
        for ( const i in headers ) {
            if ( headers[ i ].hasOwnProperty( "key" )
                && headers[ i ].hasOwnProperty( "value" ) ) {
                this._headers.push( [ headers[ i ].key, headers[ i ].value ] );
            }
        }
        return this;
    }

    get headers (): string[][] {
        return this._headers;
    }

    public resetHeaders (): void {
        this._headers = [];
    }

    public setMethod ( newMethod: HttpMethod ): APIService {
        this._method = newMethod;
        return this;
    }

    get method (): HttpMethod {
        return this._method;
    }

    public get endpoint (): string {
        return this._endpoint;
    }

    public set endpoint ( value: string ) {
        this._endpoint = value;
    }

    public request<T> (): Promise<TemperatureResponse> {
        return new Promise<any>( ( resolve, reject ) => {
            get( this._url + this.endpoint, res => {
                let body = "";

                if ( res.statusCode === 404 ) {
                    reject( new NotFound( res.statusMessage ) );
                    return;
                }

                res.on( "data", data => {
                    body += data;
                } );

                res.on( "error", err => {
                    console.log();
                    reject( err );
                } );

                res.on( "end", () => {
                    body = JSON.parse( body );
                    resolve( body );
                } );
            } );
        } );
    }
}

export default APIService;
