import APIService from "./APIService";

export class ContainerService extends APIService {
    private readonly _id: string;

    constructor ( id: string ) {
        super();

        this._id = id;
        this.endpoint = `/sensor/${ this._id }`;
    }
}
