export type ApiHeader = {
    key: string;
    value: string;
};

export enum HttpMethod {
    GET = "GET",
    POST = "POST",
    PUT = "PUT",
    DELETE = "DELETE",
}

export type ApiResult = "success" | "failure";

export type ApiError = {
    ErrorCode: string,
    Description: string,
};

export type ApiResponse<T> = {
    Result: ApiResult,
    Response: T | ApiError,
};

export type KeyValue<T, U> = {
    key: T,
    value: U,
};
