export let definedResponse = {
    id:          "31cadfeb-63c6-427c-8784-43772ab6858e",
    temperature: 0
};
