import { NotFound } from "@curveball/http-errors";
import { expect } from "chai";
import APIService from "../../src/service/APIService";
import nock = require("nock");

describe( "APIService", () => {
    let api: APIService;

    beforeEach( () => {
        nock( "https://temperature-sensor-service.herokuapp.com" )
            .get( "/" )
            .reply( 404 );

        api = new APIService();
    } );

    it( "should return new APIService", () => {
        expect( api ).to.be.an.instanceof( APIService );
    } );

    it( "should reject with a 404 NotFound error", () => {
        return api.request().then( value => {
            throw "Not found";
        } ).catch( ( reason: NotFound ) => {
            expect( reason.httpStatus ).to.be.equal( 404 );
        } );
    } );
} );
