import { expect } from "chai";
import { ContainerService } from "../../src/service/ContainerService";
import { definedResponse } from "./response";
import nock = require("nock");

describe( "ContainerService", () => {
    let sensor: ContainerService;

    beforeEach( () => {

        sensor = new ContainerService( definedResponse.id! );

        nock( "https://temperature-sensor-service.herokuapp.com" )
            .get( `/sensor/${ definedResponse.id }` )
            .reply( 200, {
                "id":          definedResponse.id,
                "temperature": 8
            } );
    } );

    it( "should return new ContainerService", () => {
        expect( sensor ).to.be.an.instanceof( ContainerService );
    } );

    it( "should resolve with a temperature object", () => {
        return sensor.request().then( value => {
            expect( value ).to.be.a( "object" ).that.does.deep.equal( {
                "id":          definedResponse.id,
                "temperature": 8
            } );
        } );
    } );
} );
